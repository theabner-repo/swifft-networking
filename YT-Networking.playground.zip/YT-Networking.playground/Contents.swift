// Networking con Generics
// 📸✨ www.instagram.com/abner.abbey

import Foundation
import UIKit

enum Endpoint {
    
    case feed

}

enum Errors: Error {
    case APIError
}

extension Endpoint {
    
    var request: URLRequest {
        
        switch self {
        case .feed:
            guard let url = URL(string: "") else { fatalError("Invalid URL") }
            
            return URLRequest(url: url)
        }
        
    }
    
}

protocol Requester {
    
    associatedtype Model
    
    func request(_ endpoint: Endpoint, completion: @escaping (Result<Model, Error>) -> ())
}

struct AnyRequester<T>: Requester {
    
    private let _request: (_: Endpoint, _: @escaping (Result<T, Error>) -> ()) -> ()
    
    init<U: Requester>(requester: U) where U.Model == T {
        
        self._request = requester.request
        
    }
    
    func request(_ endpoint: Endpoint, completion: @escaping (Result<T, Error>) -> ()) {
        
        _request(endpoint, completion)
        
    }
    
}

class DefaultImplementation<T: Decodable>: Requester {
    
    typealias Model = T
    
    func request(_ endpoint: Endpoint, completion: @escaping (Result<Model, Error>) -> ()) {
        
        let request = endpoint.request
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let data = data else {
                completion(.failure(Errors.APIError))
                return
            }
            
            do {
                let result = try JSONDecoder().decode(Model.self, from: data)
                completion(.success(result))
            } catch {
                completion(.failure(error))
            }
            
        }
        
        
    }
    
}

struct Model {
    
}

class ViewModel {
    
    let fetcher: AnyRequester<Model>
    
    init(fetcher: AnyRequester<Model>) {
        self.fetcher = fetcher
    }
}
